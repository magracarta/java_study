package com.mobliefactory.lotto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MobilefactoryLottoApplicationTests {

    @Test
    void contextLoads() {
    }

}
